s=2;
b=3;
c=s+b;